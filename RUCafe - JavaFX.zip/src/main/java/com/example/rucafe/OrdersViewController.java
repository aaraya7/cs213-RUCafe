package com.example.rucafe;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
/**
 Controller for the view used to check all the store's orders.
 @author Aaditya Rayadurgam
 */
public class OrdersViewController {
    @FXML
    private ComboBox<String> orderNumbers;
    @FXML
    private ListView<String> order;
    @FXML
    private TextField totalAmount;
    @FXML
    private Button cancelOrder;
    @FXML
    private Button exportOrders;
    private ObservableList<String> numbers;
    private ObservableList<String> orderItems;
    private CafeMainController cafeMainController;

    /**
     Initializes the data source for the order number combo box.
     */
    public void initialize(){
        numbers = FXCollections.observableArrayList();
    }
    public void setMainController (CafeMainController controller) {
        cafeMainController = controller;
        for(int i = 0; i < cafeMainController.getOrders().size(); i++){
           numbers.add("" + cafeMainController.getOrders().get(i).getOrderNumber());
        }
            orderNumbers.setItems(numbers);
            try{
                orderNumbers.setValue(numbers.get(0));
                cancelOrder.setDisable(false);
                exportOrders.setDisable(false);
            }catch(Exception e){
                cancelOrder.setDisable(true);
                exportOrders.setDisable(true);
            }
        onOrderSelectorPress();
    }

    /**
     Populates the list view with the relevant items and disables the cancel and export buttons if there are no orders.
     */
    @FXML
    protected void onOrderSelectorPress(){
        int selection = orderNumbers.getSelectionModel().getSelectedIndex();
        if(selection >= 0){
            Order toDisplay = cafeMainController.getOrders().get(selection);
            orderItems = FXCollections.observableArrayList();
            for(int i = 0; i < toDisplay.getItemList().size(); i++){
                orderItems.add(toDisplay.getItemList().get(i).toString());
            }
            order.setItems(orderItems);
            cancelOrder.setDisable(false);
            exportOrders.setDisable(false);
        }else{
            orderItems = FXCollections.observableArrayList();
            order.setItems(orderItems);
            cancelOrder.setDisable(true);
            exportOrders.setDisable(true);
        }
        displayAmount();
    }

    /**
     Displays the total cost including sales tax of the selected order.
     */
    public void displayAmount(){
        DecimalFormat df = new DecimalFormat("##,###.00");
        if(orderItems != null){
            double price = 0;
            for(int i = 0; i < orderItems.size(); i++) {
                price += menuItemPrice(orderItems.get(i));
            }
            totalAmount.setText("$" + df.format(price));
        }else{
            totalAmount.setText("$" + df.format(0));
        }
    }

    /**
     Finds the price of an item, including sales tax.
     @param toCheck the item to find the price of
     @return the price, including sales tax.
     */
    public double menuItemPrice(String toCheck){
        double price = 0;
        if(toCheck.contains("Coffee")){
            String[] checkPrice = toCheck.split(" ");
            if(checkPrice.length == 3){
                price += new Coffee(checkPrice[2], Integer.parseInt(checkPrice[1].substring(1,2)),
                        0).itemPrice();
            }else{
                int numAddIns = toCheck.length() - toCheck.replace(",", "").length() + 1;
                price += new Coffee(checkPrice[2], Integer.parseInt(checkPrice[1].substring(1,2)),
                        numAddIns).itemPrice();
            }
        }else{
            String[] checkPrice = toCheck.split(" \\(");
            price += new Donut(checkPrice[0], Integer.parseInt(checkPrice[1].substring(0, checkPrice[1].length()-1)),
                    checkPrice[2].substring(0, checkPrice[2].length()-1)).itemPrice();
        }
        return price*1.06625;
    }

    /**
     Cancels an order.
     */
    @FXML
    protected void onCancelButtonPress(){
        int cancelNumber = orderNumbers.getSelectionModel().getSelectedIndex();
        cafeMainController.getOrders().remove(cancelNumber);
        orderNumbers.getItems().remove(cancelNumber);
        orderNumbers.getSelectionModel().select(0);
        displayAmount();
    }

    /**
     Exports all the available orders to a txt file.
     */
    @FXML
    protected void onExportButtonPress() throws IOException {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter filter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(filter);
        File file = fileChooser.showOpenDialog(null);
        FileWriter fileWriter = new FileWriter(file, false);
        for(int i = 0; i < orderNumbers.getItems().size(); i++){
            orderNumbers.getSelectionModel().select(i);
            fileWriter.write("Order Number: " + orderNumbers.getSelectionModel().getSelectedItem() + "\n");
            for(int j = 0; j < orderItems.size(); j++){
                fileWriter.write(orderItems.get(j) + "\n");
            }
            fileWriter.write("\n");
        }
        fileWriter.close();
    }
}