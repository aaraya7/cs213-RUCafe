package com.example.rucafe;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
/**
 Controller for the view used to navigate to the other four views.
 @author Aaditya Rayadurgam
 */
public class CafeMainController {
    private Order cart;
    private int orderNumber;
    private ArrayList<Order> orders;

    /**
     Constructor to initialize the instance variables.
     */
    public CafeMainController(){
        orderNumber = 1;
        cart = new Order(orderNumber);
        orders = new ArrayList<>();
    }

    /**
     Loads the view for ordering coffee.
     */
    @FXML
    protected void onCoffeeButtonPress() {
        Stage coffeeView = new Stage();
        BorderPane root;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("coffee-view.fxml"));
            root = (BorderPane) loader.load();
            CoffeeViewController coffeeViewController = loader.getController();
            coffeeViewController.setMainController(this);
            Scene scene = new Scene(root, 600, 600);
            coffeeView.setScene(scene);
            coffeeView.show();
        }catch(IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Loading coffee-view.fxml.");
            alert.setContentText("Couldn't load coffee-view.fxml.");
            alert.showAndWait();
        }
    }

    /**
     Loads the view for ordering donuts.
     */
    @FXML
    protected void onDonutButtonPress() {
        Stage donutView = new Stage();
        BorderPane root;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("donut-view.fxml"));
            root = (BorderPane) loader.load();
            DonutViewController donutViewController = loader.getController();
            donutViewController.setMainController(this);
            Scene scene = new Scene(root, 600, 600);
            donutView.setScene(scene);
            donutView.show();
        }catch(IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Loading donut-view.fxml.");
            alert.setContentText("Couldn't load donut-view.fxml.");
            alert.showAndWait();
        }
    }

    /**
     Loads the view for checking the virtual shopping cart.
     */
    @FXML
    protected void onCartButtonPress() {
        Stage cartView = new Stage();
        BorderPane root;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("cart-view.fxml"));
            root = (BorderPane) loader.load();
            CartViewController cartViewController = loader.getController();
            cartViewController.setMainController(this);
            Scene scene = new Scene(root, 600, 600);
            cartView.setScene(scene);
            cartView.show();
        }catch(IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Loading cart-view.fxml.");
            alert.setContentText("Couldn't load cart-view.fxml.");
            alert.showAndWait();
        }
    }

    /**
     Loads the view for checking all orders.
     */
    @FXML
    protected void onOrdersButtonPress() {
        Stage ordersView = new Stage();
        BorderPane root;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("orders-view.fxml"));
            root = (BorderPane) loader.load();
            OrdersViewController ordersViewController = loader.getController();
            ordersViewController.setMainController(this);
            Scene scene = new Scene(root, 600, 600);
            ordersView.setScene(scene);
            ordersView.show();
        }catch(IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Loading orders-view.fxml.");
            alert.setContentText("Couldn't load orders-view.fxml.");
            alert.showAndWait();
        }
    }

    /**
     Adds an item to the order.
     */
    public void addToOrder(MenuItem toAdd){
        cart.addItem(toAdd);
    }

    /**
     Removes an item from the order.
     */
    public void removeFromOrder(MenuItem toRemove){
        cart.removeItem(toRemove);
    }

    /**
     Returns the virtual shopping cart.
     @return the list with the current order
     */
    public Order getCart(){
        return cart;
    }

    /**
     Returns the list of orders.
     @return an ArrayList of separate orders
     */
    public ArrayList<Order> getOrders(){
        return orders;
    }

    /**
     Places an order to the store.
     */
    public void placeOrder(){
        orders.add(cart);
        orderNumber++;
        cart = new Order(orderNumber);
    }
}