package com.example.rucafe;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import java.text.DecimalFormat;
/**
 Controller for the view used to order coffee.
 @author Aaditya Rayadurgam
 */
public class CoffeeViewController{
    private CafeMainController cafeMainController;
    @FXML
    private ComboBox<String> cmb_size;
    @FXML
    private ComboBox<String> cmb_quantity;
    @FXML
    private TextField price;
    @FXML
    private CheckBox sweetCream;
    @FXML
    private CheckBox frenchVanilla;
    @FXML
    private CheckBox irishCream;
    @FXML
    private CheckBox caramel;
    @FXML
    private CheckBox mocha;

    /**
     Initializes the combo boxes and their data sources.
     */
    public void initialize(){
        ObservableList<String> size = FXCollections.observableArrayList("Short", "Tall", "Grande", "Venti");
        ObservableList<String> quantity = FXCollections.observableArrayList("1", "2", "3", "4", "5");
        cmb_size.setItems(size);
        cmb_size.setValue("Short");
        cmb_quantity.setItems(quantity);
        cmb_quantity.setValue("1");
        priceUpdate();
    }
    /**
     Defines the main controller.
     */
    public void setMainController (CafeMainController controller){
        cafeMainController = controller;
    }

    /**
     Calculates and updates the price of the coffee.
     */
    @FXML
    public void priceUpdate(){
        DecimalFormat df = new DecimalFormat("##,###.00");
        String currentPrice = df.format(createCoffee().itemPrice());
        price.setText("$" + currentPrice);
    }

    /**
     Creates a coffee object from user input.
     @return a coffee object
     */
    public Coffee createCoffee(){
        String coffeeSize = cmb_size.getSelectionModel().getSelectedItem();
        int coffeeQuantity = Integer.parseInt(cmb_quantity.getSelectionModel().getSelectedItem());
        boolean sweetCream = false;
        boolean frenchVanilla = false;
        boolean irishCream = false;
        boolean caramel = false;
        boolean mocha = false;
        if(this.sweetCream.isSelected()){
            sweetCream = true;
        }
        if(this.frenchVanilla.isSelected()){
            frenchVanilla = true;
        }
        if(this.irishCream.isSelected()){
            irishCream = true;
        }
        if(this.caramel.isSelected()){
            caramel = true;
        }
        if(this.mocha.isSelected()){
            mocha = true;
        }
        return new Coffee(coffeeSize, coffeeQuantity, sweetCream, frenchVanilla, irishCream, caramel, mocha);
    }

    /**
     Adds a coffee to the order when the Add To Order button is pressed.
     */
    @FXML
    protected void onAddButtonPress(){
        cafeMainController.addToOrder(createCoffee());
    }
}
