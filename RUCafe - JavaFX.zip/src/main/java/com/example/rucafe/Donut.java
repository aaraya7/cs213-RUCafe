package com.example.rucafe;
/**
 Creates a Donut object with a type and a flavor.
 @author Aaditya Rayadurgam
 */
public class Donut extends MenuItem{
    private String flavor;
    private String type;
    private int quantity;
    public static final double YEAST_PRICE = 1.59;
    public static final double CAKE_PRICE = 1.79;
    public static final double HOLE_PRICE = .39;

    /**
     Constructor to initialize the instance variables.
     @param type yeast donut, cake donut, or a donut hole
     @param quantity number of donuts ordered
     @param flavor flavor of the donut
     */
    public Donut(String type, int quantity, String flavor){
        this.type = type;
        this.quantity = quantity;
        this.flavor = flavor;
    }

    /**
     Calculates and returns the price of the donut as a double.
     @return price of the donut
     */
    @Override
    public double itemPrice() {
        double price = 0;
        if(type.equals("Yeast Donut")){
            price += YEAST_PRICE;
        }else if(type.equals("Cake Donut")){
            price += CAKE_PRICE;
        }else if(type.equals("Donut Hole")){
            price += HOLE_PRICE;
        }
        return price*quantity;
    }

    /**
     Overrides the toString() method of the Object class.
     @return type and flavor of the donut in the format "type (quantity) (flavor)"
     */
    @Override
    public String toString() {
        return type + " (" + quantity + ") (" + flavor + ")";
    }
}
