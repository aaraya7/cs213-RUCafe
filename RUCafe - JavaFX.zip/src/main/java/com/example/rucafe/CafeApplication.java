package com.example.rucafe;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 Model class to set the stage for the project.
 @author Aaditya Rayadurgam
 */
public class CafeApplication extends Application {
    /**
     Creates the stage and sets the scene.
     @param stage is the stage
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(CafeApplication.class.getResource("cafe-main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 600);
        stage.setTitle("Project 4 - RUCafe");
        stage.setScene(scene);
        stage.show();
    }

    /**
     Launches the program.
     */
    public static void main(String[] args) {
        launch();
    }
}