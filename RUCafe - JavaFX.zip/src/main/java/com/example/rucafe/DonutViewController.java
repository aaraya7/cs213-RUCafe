package com.example.rucafe;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.text.DecimalFormat;
/**
 Controller for the view used to order donuts.
 @author Aaditya Rayadurgam
 */
public class DonutViewController {
    private CafeMainController cafeMainController;
    private ObservableList<String> yeastDonuts;
    private ObservableList<String> cakeDonuts;
    private ObservableList<String> donutHoles;
    private ObservableList<String> numbers;
    private ObservableList<String> orderedDonuts;
    @FXML
    private ListView<String> donutStock;
    @FXML
    private ListView<String> orderList;
    @FXML
    private ComboBox<String> typeSelector;
    @FXML
    private ComboBox<String> quantity;
    @FXML
    private ImageView donutImage;
    @FXML
    private TextField subtotal;

    /**
     Defines the main controller.
     */
    public void setMainController (CafeMainController controller){
        cafeMainController = controller;
    }

    /**
     Initializes the list views of donut flavors, the associated images, and the combo box for the amount of donuts.
     */
    public void initialize(){
        yeastDonuts = FXCollections.observableArrayList("Jelly", "Glazed", "Chocolate Frosted",
                "Strawberry Frosted", "Lemon-Filled", "Apple Bite");
        cakeDonuts = FXCollections.observableArrayList("Salted Caramel", "Blue",
                "Chocolate Sprinkle", "Jelly Glazed");
        donutHoles = FXCollections.observableArrayList("Pretzel", "Chocolate Glazed", "Pumpkin Pie", "France");
        donutStock.setItems(yeastDonuts);
        ObservableList<String> types = FXCollections.observableArrayList(
                "Yeast Donut", "Cake Donut", "Donut Hole");
        typeSelector.setItems(types);
        typeSelector.setValue("Yeast Donut");
        numbers = FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12");
        quantity.setItems(numbers);
        quantity.setValue("1");
        donutImage.setImage(new Image(getClass().getResourceAsStream("yeastdonut.jpg")));
        orderedDonuts = FXCollections.observableArrayList();
        orderList.setItems(orderedDonuts);
        updatePrice();
    }

    /**
     Changes the flavor options and displayed picture based on the selected type of donut.
     */
    @FXML
    protected void onTypeSelect(){
        if(typeSelector.getSelectionModel().getSelectedItem().equals("Yeast Donut")){
            donutStock.setItems(yeastDonuts);
            donutImage.setImage(new Image(getClass().getResourceAsStream("yeastdonut.jpg")));
        }else if(typeSelector.getSelectionModel().getSelectedItem().equals("Cake Donut")){
            donutStock.setItems(cakeDonuts);
            donutImage.setImage(new Image(getClass().getResourceAsStream("cakedonut.jpg")));
        }else if(typeSelector.getSelectionModel().getSelectedItem().equals("Donut Hole")){
            donutStock.setItems(donutHoles);
            donutImage.setImage(new Image(getClass().getResourceAsStream("donutholes.jpg")));
        }
    }

    /**
     Adds a donut to the pre-order list.
     */
    @FXML
    protected void onAddButtonPress(){
        int index = donutStock.getSelectionModel().getSelectedIndex();
        if(index >= 0){
            String flavor = donutStock.getItems().get(index);
            int quantity = Integer.parseInt(this.quantity.getSelectionModel().getSelectedItem());
            String type = this.typeSelector.getSelectionModel().getSelectedItem();
            Donut ordered = new Donut(type, quantity, flavor);
            orderedDonuts.add(ordered.toString());
            donutStock.getItems().remove(index);
            updatePrice();
        }
    }

    /**
     Removes a donut from the pre-order list.
     */
    @FXML
    protected void onRemoveButtonPress(){
        int index = orderList.getSelectionModel().getSelectedIndex();
        if(index >= 0){
            String[] toRemove = orderList.getItems().get(index).split("\\(");
            if(toRemove[0].equals("Yeast Donut ")){
                yeastDonuts.add(toRemove[2].substring(0, toRemove[2].length()-1));
            }else if(toRemove[0].equals("Cake Donut ")){
                cakeDonuts.add(toRemove[2].substring(0, toRemove[2].length()-1));
            }else if(toRemove[0].equals("Donut Hole ")) {
                donutHoles.add(toRemove[2].substring(0, toRemove[2].length()-1));
            }
            orderList.getItems().remove(index);
            updatePrice();
        }
    }

    /**
     Calculates and updates the price of the order.
     */
    public void updatePrice(){
        DecimalFormat df = new DecimalFormat("##,###.00");
        double price = 0;
        for(int i = 0; i < orderList.getItems().size(); i++){
            String[] checkPrice = orderList.getItems().get(i).split(" \\(");
            price += new Donut(checkPrice[0], Integer.parseInt(checkPrice[1].substring(0, checkPrice[1].length()-1)),
                    checkPrice[2].substring(0, checkPrice[2].length()-1)).itemPrice();
        }
        subtotal.setText("$" + df.format(price));
    }

    /**
     Adds the list of selected donuts to the order.
     */
    @FXML
    protected void onAddToOrderButtonPress(){
        for(int i = 0; i < orderList.getItems().size(); i++){
            String[] addToOrder = orderList.getItems().get(i).split(" \\(");
            cafeMainController.addToOrder(new Donut(addToOrder[0], Integer.parseInt(addToOrder[1].substring(0,
                    addToOrder[1].length()-1)), addToOrder[2].substring(0, addToOrder[2].length()-1)));
        }
    }
}
