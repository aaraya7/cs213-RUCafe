package com.example.rucafe;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.text.DecimalFormat;
/**
 Controller for the view used to check the virtual shopping cart.
 @author Aaditya Rayadurgam
 */
public class CartViewController {
    @FXML
    private ListView<String> listCart;
    @FXML
    private TextField subtotal;
    @FXML
    private TextField salesTax;
    @FXML
    private TextField totalAmount;
    private CafeMainController cafeMainController;
    private ObservableList<String> cartList;
    private static final double SALES_TAX = .06625;

    /**
     Initialize method defining a data source for the cart list.
     */
    public void initialize(){
        cartList = FXCollections.observableArrayList();
        listCart.setItems(cartList);
    }

    /**
     Method used to define the main controller and to populate the cart list.
     @param controller is the main controller
     */
    public void setMainController (CafeMainController controller){
        cafeMainController = controller;
        for(int i = 0; i < cafeMainController.getCart().getItemList().size(); i++){
            cartList.add(cafeMainController.getCart().getItemList().get(i).toString());
        }
        displayAmounts();
    }

    /**
     Helper method to display the different amounts of money.
     */
    protected void displayAmounts(){
        DecimalFormat df = new DecimalFormat("##,###.00");
        double price = 0;
        for(int i = 0; i < cafeMainController.getCart().getItemList().size(); i++){
            price += cafeMainController.getCart().getItemList().get(i).itemPrice();
        }
        subtotal.setText("$" + df.format(price));
        salesTax.setText("$" + df.format(price*SALES_TAX));
        totalAmount.setText("$" + df.format(price+(price*SALES_TAX)));
    }

    /**
     Removes an item from the virtual shopping cart and updates the price.
     */
    @FXML
    protected void onRemoveButtonPress(){
        int index = listCart.getSelectionModel().getSelectedIndex();
        if(index >= 0){
            cafeMainController.removeFromOrder(cafeMainController.getCart().getItemList().get(index));
            cartList.remove(index);
        }
        displayAmounts();
    }

    /**
     Clears the shopping cart and places an order.
     */
    @FXML
    protected void onPlaceOrderButtonPress(){
        if(cartList.size() > 0){
            cafeMainController.placeOrder();
            for(int i = cartList.size()-1; i >= 0; i--){
                cartList.remove(i);
            }
        }
    }
}
