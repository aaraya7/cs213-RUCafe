package com.example.rucafe;

/**
 Abstract class with an abstract methods.
 @author Aaditya Rayadurgam
 */
public abstract class MenuItem{
    public abstract double itemPrice();
    /**
     Empty default constructor
     */
    public MenuItem() {
    }
}