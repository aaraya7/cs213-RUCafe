package com.example.rucafe;

/**
 Creates a Coffee object with a size and add-ins.
 @author Aaditya Rayadurgam
 */
public class Coffee extends MenuItem{
    private String size;
    private int quantity;
    private boolean sweetCream;
    private boolean frenchVanilla;
    private boolean irishCream;
    private boolean caramel;
    private boolean mocha;
    public static final double BASE_PRICE = 1.89;
    public static final double SIZE_UP = .40;
    public static final double ADD_IN = .30;
    public static final int BUFFER = 2;

    /**
     Constructor to initialize the instance variables.
     @param size the size of the coffee
     @param quantity the number of coffees ordered
     @param sweetCream whether sweet cream is added
     @param frenchVanilla whether french vanilla is added
     @param irishCream whether irish cream is added
     @param caramel whether caramel is added
     @param mocha whether mocha is added
     */
    public Coffee(String size, int quantity, boolean sweetCream, boolean frenchVanilla,
                  boolean irishCream, boolean caramel, boolean mocha){
        this.size = size;
        this.quantity = quantity;
        this.sweetCream = sweetCream;
        this.frenchVanilla = frenchVanilla;
        this.irishCream = irishCream;
        this.caramel = caramel;
        this.mocha = mocha;
    }
    /**
     Constructor that initializes the instance variables using the number of add-ins instead of the actual values.
     @param size the size of the coffee
     @param quantity the number of coffees ordered
     @param numAddIns the number of addIns
     */
    public Coffee(String size, int quantity, int numAddIns){
        this.size = size;
        this.quantity = quantity;
        this.sweetCream = false;
        this.frenchVanilla = false;
        this.irishCream = false;
        this.caramel = false;
        this.mocha = false;
        for(int i = 0; i < numAddIns; i++){
            if(i == 0){
                this.sweetCream = true;
            }else if(i == 1){
                this.frenchVanilla = true;
            }else if(i == 2){
                this.irishCream = true;
            }else if(i == 3){
                this.caramel = true;
            }else if(i == 4){
                this.mocha = true;
            }
        }
    }

    /**
     Calculates and returns the price of the coffee as a double.
     @return price of the coffee
     */
    @Override
    public double itemPrice() {
        double price = BASE_PRICE;

        if(size.equals("Tall")){
            price += SIZE_UP;
        }else if(size.equals("Grande")){
            price += SIZE_UP*2;
        }else if(size.equals("Venti")){
            price += SIZE_UP*3;
        }

        if(sweetCream){
            price += ADD_IN;
        }
        if(frenchVanilla){
            price += ADD_IN;
        }
        if(irishCream){
            price += ADD_IN;
        }
        if(caramel){
            price += ADD_IN;
        }
        if(mocha){
            price += ADD_IN;
        }
        return price*quantity;
    }

    /**
     Overrides the toString() method of the Object class.
     @return size and add-ins in the format "Coffee (quantity) size (add-ins)"
     */
    @Override
    public String toString() {
        String coffee = "Coffee (" + quantity + ") " + size + " (";
        if(sweetCream){
            coffee += "Sweet Cream, ";
        }
        if(frenchVanilla){
            coffee += "French Vanilla, ";
        }
        if(irishCream){
            coffee += "Irish Cream, ";
        }
        if(caramel){
            coffee += "Caramel, ";
        }
        if(mocha){
            coffee += "Mocha, ";
        }
        coffee = coffee.substring(0, coffee.length()-BUFFER);
        if(sweetCream || frenchVanilla || irishCream || caramel || mocha){
            coffee  += ")";
        }
        return coffee;
    }
}
